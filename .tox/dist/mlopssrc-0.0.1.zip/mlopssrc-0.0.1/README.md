download the data from

https://drive.google.com/drive/folders/18zqQiCJVgF7uzXgfbIJ-04zgz1ItNfF5?usp=sharing


tox command-
'''bash
tox
'''

for tox rebuilding command-
'''bash
tox -r
'''

pytest command-
'''bash
pytest -v
'''

setup commands-
'''bash
pip install -e .
'''