from setuptools import setup, find_packages

setup(
    name="mlopssrc",
    version="0.0.1",
    description="its MLOps package", 
    author="c17hawke", 
    packages=find_packages(),
    license="MIT"
)
